/*
 * =====================================================================================
 *
 *       Filename:  Math.h
 *
 *    Description:  This is a simple Math class with basic arithmetic operations
 *
 *        Version:  1.0
 *        Created:  12/09/2016 05:47:22 PM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Jeganathan Swaminathan <jegan@tektutor.org>
 *   Organization:  TekTutor <http://www.tektutor.org>
 *
 * =====================================================================================
 */

class Math {
public:
			 int add(int,int);
};
